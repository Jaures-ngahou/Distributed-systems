#include <stdio.h>
#include <stdlib.h>


void decoupeMinutes(int *pheures, int *pminutes)
{
    *pheures = *pminutes / 60;  // 90 / 60 = 1
    *pminutes = *pminutes % 60; // 90 % 60 = 30
    printf("%d heures et %d minutes \n", *pheures, *pminutes);
}



int main(void)
{
    int heures = 0, minutes = 90;       
    int *pheures = &heures ;
    int *pminutes = &minutes ;

   

    decoupeMinutes(pheures, pminutes);

    printf("%d heures et %d minutes \n", heures, minutes);

    return 0;
}

